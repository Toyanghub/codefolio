<?php

namespace App\Http\Controllers;

use App\Services\OtpService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class EmailVerificationController extends Controller
{
    public function __construct(
        protected OtpService $otpService
    ) {}

    /**
     * Display the email verification page
     */
    public function show(Request $request): Response|RedirectResponse
    {
        $user = $request->user();
        
        // Redirect unauthenticated users to login
        if (!$user) {
            return redirect()->route('login')
                ->with('error', 'Please log in to verify your email.');
        }
        
        // If already verified, redirect to intended destination
        if ($user->email_verified) {
            return redirect()->intended(route('home'));
        }
        
        $remainingTime = $this->otpService->getRemainingTime($user);
        $canRequestOtp = $this->otpService->canRequestOtp($user);

        return Inertia::render('auth/verify-email-otp', [
            'remainingTime' => $remainingTime,
            'canRequestOtp' => $canRequestOtp['can_request'],
            'rateLimitMessage' => $canRequestOtp['message'],
        ]);
    }

    /**
     * Verify the OTP code
     */
    public function verifyOtp(Request $request): RedirectResponse
    {
        $request->validate([
            'otp' => ['required', 'string', 'size:6'],
        ]);

        $user = $request->user();
        
        // Redirect unauthenticated users to login
        if (!$user) {
            return redirect()->route('login')
                ->with('error', 'Please log in to verify your email.');
        }
        $result = $this->otpService->verifyOtp($user, $request->otp);

        if ($result['success']) {
            // Refresh the user in session to update email_verified status
            $request->user()->refresh();
            
            return redirect()->intended(route('home'))
                ->with('success', $result['message']);
        }

        return back()->withErrors([
            'otp' => $result['message'],
        ]);
    }

    /**
     * Resend OTP code
     */
    public function resendOtp(Request $request): RedirectResponse
    {
        $user = $request->user();
        
        // Redirect unauthenticated users to login
        if (!$user) {
            return redirect()->route('login')
                ->with('error', 'Please log in to verify your email.');
        }
        
        $canRequest = $this->otpService->canRequestOtp($user);
        
        if (!$canRequest['can_request']) {
            return back()->withErrors([
                'otp' => $canRequest['message'],
            ]);
        }

        $sent = $this->otpService->generateAndSendOtp($user);

        if ($sent) {
            return back()->with('success', 'A new verification code has been sent to your email.');
        }

        return back()->withErrors([
            'otp' => 'Failed to send verification code. Please try again later.',
        ]);
    }
}
