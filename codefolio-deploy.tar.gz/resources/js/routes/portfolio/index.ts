import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import screenshots from './screenshots'
import desktopImage from './desktop-image'
import mobileImage from './mobile-image'
import websiteUrl from './website-url'
import description from './description'
import skills from './skills'
import techStacks from './tech-stacks'
import professions from './professions'
/**
* @see \App\Http\Controllers\PortfolioDetailController::detail
 * @see app/Http/Controllers/PortfolioDetailController.php:14
 * @route '/portfolio/{id}'
 */
export const detail = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detail.url(args, options),
    method: 'get',
})

detail.definition = {
    methods: ["get","head"],
    url: '/portfolio/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PortfolioDetailController::detail
 * @see app/Http/Controllers/PortfolioDetailController.php:14
 * @route '/portfolio/{id}'
 */
detail.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return detail.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PortfolioDetailController::detail
 * @see app/Http/Controllers/PortfolioDetailController.php:14
 * @route '/portfolio/{id}'
 */
detail.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detail.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PortfolioDetailController::detail
 * @see app/Http/Controllers/PortfolioDetailController.php:14
 * @route '/portfolio/{id}'
 */
detail.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: detail.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PortfolioDetailController::detail
 * @see app/Http/Controllers/PortfolioDetailController.php:14
 * @route '/portfolio/{id}'
 */
    const detailForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: detail.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PortfolioDetailController::detail
 * @see app/Http/Controllers/PortfolioDetailController.php:14
 * @route '/portfolio/{id}'
 */
        detailForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: detail.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PortfolioDetailController::detail
 * @see app/Http/Controllers/PortfolioDetailController.php:14
 * @route '/portfolio/{id}'
 */
        detailForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: detail.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    detail.form = detailForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/portfolio',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::complete
 * @see app/Http/Controllers/Settings/PortfolioController.php:231
 * @route '/settings/portfolio/complete'
 */
export const complete = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/settings/portfolio/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::complete
 * @see app/Http/Controllers/Settings/PortfolioController.php:231
 * @route '/settings/portfolio/complete'
 */
complete.url = (options?: RouteQueryOptions) => {
    return complete.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::complete
 * @see app/Http/Controllers/Settings/PortfolioController.php:231
 * @route '/settings/portfolio/complete'
 */
complete.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::complete
 * @see app/Http/Controllers/Settings/PortfolioController.php:231
 * @route '/settings/portfolio/complete'
 */
    const completeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::complete
 * @see app/Http/Controllers/Settings/PortfolioController.php:231
 * @route '/settings/portfolio/complete'
 */
        completeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(options),
            method: 'post',
        })
    
    complete.form = completeForm
const portfolio = {
    detail: Object.assign(detail, detail),
edit: Object.assign(edit, edit),
complete: Object.assign(complete, complete),
screenshots: Object.assign(screenshots, screenshots),
desktopImage: Object.assign(desktopImage, desktopImage),
mobileImage: Object.assign(mobileImage, mobileImage),
websiteUrl: Object.assign(websiteUrl, websiteUrl),
description: Object.assign(description, description),
skills: Object.assign(skills, skills),
techStacks: Object.assign(techStacks, techStacks),
professions: Object.assign(professions, professions),
}

export default portfolio