import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:54
 * @route '/settings/portfolio/website-url'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/settings/portfolio/website-url',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:54
 * @route '/settings/portfolio/website-url'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:54
 * @route '/settings/portfolio/website-url'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:54
 * @route '/settings/portfolio/website-url'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:54
 * @route '/settings/portfolio/website-url'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const websiteUrl = {
    update: Object.assign(update, update),
}

export default websiteUrl