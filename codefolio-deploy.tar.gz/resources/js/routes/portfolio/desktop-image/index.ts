import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:149
 * @route '/settings/portfolio/desktop-image'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/settings/portfolio/desktop-image',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:149
 * @route '/settings/portfolio/desktop-image'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:149
 * @route '/settings/portfolio/desktop-image'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:149
 * @route '/settings/portfolio/desktop-image'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:149
 * @route '/settings/portfolio/desktop-image'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteMethod
 * @see app/Http/Controllers/Settings/PortfolioController.php:201
 * @route '/settings/portfolio/desktop-image'
 */
export const deleteMethod = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMethod.url(options),
    method: 'delete',
})

deleteMethod.definition = {
    methods: ["delete"],
    url: '/settings/portfolio/desktop-image',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteMethod
 * @see app/Http/Controllers/Settings/PortfolioController.php:201
 * @route '/settings/portfolio/desktop-image'
 */
deleteMethod.url = (options?: RouteQueryOptions) => {
    return deleteMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteMethod
 * @see app/Http/Controllers/Settings/PortfolioController.php:201
 * @route '/settings/portfolio/desktop-image'
 */
deleteMethod.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMethod.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteMethod
 * @see app/Http/Controllers/Settings/PortfolioController.php:201
 * @route '/settings/portfolio/desktop-image'
 */
    const deleteMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteMethod.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteMethod
 * @see app/Http/Controllers/Settings/PortfolioController.php:201
 * @route '/settings/portfolio/desktop-image'
 */
        deleteMethodForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteMethod.form = deleteMethodForm
const desktopImage = {
    update: Object.assign(update, update),
delete: Object.assign(deleteMethod, deleteMethod),
}

export default desktopImage