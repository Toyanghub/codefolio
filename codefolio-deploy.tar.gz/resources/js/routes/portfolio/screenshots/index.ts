import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\PortfolioController::generate
 * @see app/Http/Controllers/Settings/PortfolioController.php:263
 * @route '/settings/portfolio/generate-screenshots'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/settings/portfolio/generate-screenshots',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::generate
 * @see app/Http/Controllers/Settings/PortfolioController.php:263
 * @route '/settings/portfolio/generate-screenshots'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::generate
 * @see app/Http/Controllers/Settings/PortfolioController.php:263
 * @route '/settings/portfolio/generate-screenshots'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::generate
 * @see app/Http/Controllers/Settings/PortfolioController.php:263
 * @route '/settings/portfolio/generate-screenshots'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::generate
 * @see app/Http/Controllers/Settings/PortfolioController.php:263
 * @route '/settings/portfolio/generate-screenshots'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
const screenshots = {
    generate: Object.assign(generate, generate),
}

export default screenshots