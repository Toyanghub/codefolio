import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:116
 * @route '/settings/portfolio/professions'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/settings/portfolio/professions',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:116
 * @route '/settings/portfolio/professions'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:116
 * @route '/settings/portfolio/professions'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:116
 * @route '/settings/portfolio/professions'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:116
 * @route '/settings/portfolio/professions'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const professions = {
    update: Object.assign(update, update),
}

export default professions