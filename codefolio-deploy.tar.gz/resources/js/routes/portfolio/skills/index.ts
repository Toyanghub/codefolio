import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:86
 * @route '/settings/portfolio/skills'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/settings/portfolio/skills',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:86
 * @route '/settings/portfolio/skills'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:86
 * @route '/settings/portfolio/skills'
 */
update.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:86
 * @route '/settings/portfolio/skills'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::update
 * @see app/Http/Controllers/Settings/PortfolioController.php:86
 * @route '/settings/portfolio/skills'
 */
        updateForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const skills = {
    update: Object.assign(update, update),
}

export default skills