import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../wayfinder'
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

login.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
login.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
login.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: login.url(options),
    method: 'head',
})

    /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: login.url(options),
        method: 'get',
    })

            /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
        loginForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url(options),
            method: 'get',
        })
            /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
 * @route '/login'
 */
        loginForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: login.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    login.form = loginForm
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
 * @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
 * @route '/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

register.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
register.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})
/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
register.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: register.url(options),
    method: 'head',
})

    /**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: register.url(options),
        method: 'get',
    })

            /**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
        registerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: register.url(options),
            method: 'get',
        })
            /**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
 * @route '/register'
 */
        registerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: register.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    register.form = registerForm
/**
 * @see routes/web.php:19
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:19
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:19
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:19
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:19
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:19
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:19
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \App\Http\Controllers\ObservatoryController::observatory
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
export const observatory = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: observatory.url(options),
    method: 'get',
})

observatory.definition = {
    methods: ["get","head"],
    url: '/observatory',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ObservatoryController::observatory
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
observatory.url = (options?: RouteQueryOptions) => {
    return observatory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ObservatoryController::observatory
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
observatory.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: observatory.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ObservatoryController::observatory
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
observatory.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: observatory.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ObservatoryController::observatory
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
    const observatoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: observatory.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ObservatoryController::observatory
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
        observatoryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: observatory.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ObservatoryController::observatory
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
        observatoryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: observatory.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    observatory.form = observatoryForm
/**
* @see \App\Http\Controllers\WorksController::works
 * @see app/Http/Controllers/WorksController.php:18
 * @route '/works'
 */
export const works = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: works.url(options),
    method: 'get',
})

works.definition = {
    methods: ["get","head"],
    url: '/works',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\WorksController::works
 * @see app/Http/Controllers/WorksController.php:18
 * @route '/works'
 */
works.url = (options?: RouteQueryOptions) => {
    return works.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\WorksController::works
 * @see app/Http/Controllers/WorksController.php:18
 * @route '/works'
 */
works.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: works.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\WorksController::works
 * @see app/Http/Controllers/WorksController.php:18
 * @route '/works'
 */
works.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: works.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\WorksController::works
 * @see app/Http/Controllers/WorksController.php:18
 * @route '/works'
 */
    const worksForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: works.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\WorksController::works
 * @see app/Http/Controllers/WorksController.php:18
 * @route '/works'
 */
        worksForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: works.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\WorksController::works
 * @see app/Http/Controllers/WorksController.php:18
 * @route '/works'
 */
        worksForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: works.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    works.form = worksForm
/**
 * @see routes/web.php:39
 * @route '/contact'
 */
export const contact = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})

contact.definition = {
    methods: ["get","head"],
    url: '/contact',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:39
 * @route '/contact'
 */
contact.url = (options?: RouteQueryOptions) => {
    return contact.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:39
 * @route '/contact'
 */
contact.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:39
 * @route '/contact'
 */
contact.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: contact.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:39
 * @route '/contact'
 */
    const contactForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: contact.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:39
 * @route '/contact'
 */
        contactForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contact.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:39
 * @route '/contact'
 */
        contactForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contact.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    contact.form = contactForm
/**
* @see \App\Http\Controllers\SitemapController::sitemap
 * @see app/Http/Controllers/SitemapController.php:9
 * @route '/sitemap.xml'
 */
export const sitemap = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitemap.url(options),
    method: 'get',
})

sitemap.definition = {
    methods: ["get","head"],
    url: '/sitemap.xml',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SitemapController::sitemap
 * @see app/Http/Controllers/SitemapController.php:9
 * @route '/sitemap.xml'
 */
sitemap.url = (options?: RouteQueryOptions) => {
    return sitemap.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SitemapController::sitemap
 * @see app/Http/Controllers/SitemapController.php:9
 * @route '/sitemap.xml'
 */
sitemap.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitemap.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SitemapController::sitemap
 * @see app/Http/Controllers/SitemapController.php:9
 * @route '/sitemap.xml'
 */
sitemap.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sitemap.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SitemapController::sitemap
 * @see app/Http/Controllers/SitemapController.php:9
 * @route '/sitemap.xml'
 */
    const sitemapForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sitemap.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SitemapController::sitemap
 * @see app/Http/Controllers/SitemapController.php:9
 * @route '/sitemap.xml'
 */
        sitemapForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sitemap.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SitemapController::sitemap
 * @see app/Http/Controllers/SitemapController.php:9
 * @route '/sitemap.xml'
 */
        sitemapForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sitemap.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sitemap.form = sitemapForm
/**
* @see \App\Http\Controllers\EmailVerificationController::verifyOtp
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
export const verifyOtp = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyOtp.url(options),
    method: 'get',
})

verifyOtp.definition = {
    methods: ["get","head"],
    url: '/verify-otp',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\EmailVerificationController::verifyOtp
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
verifyOtp.url = (options?: RouteQueryOptions) => {
    return verifyOtp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmailVerificationController::verifyOtp
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
verifyOtp.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: verifyOtp.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\EmailVerificationController::verifyOtp
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
verifyOtp.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: verifyOtp.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\EmailVerificationController::verifyOtp
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
    const verifyOtpForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: verifyOtp.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\EmailVerificationController::verifyOtp
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
        verifyOtpForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verifyOtp.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\EmailVerificationController::verifyOtp
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
        verifyOtpForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: verifyOtp.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    verifyOtp.form = verifyOtpForm