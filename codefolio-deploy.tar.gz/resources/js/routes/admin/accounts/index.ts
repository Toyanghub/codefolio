import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::show
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:212
 * @route '/admin/accounts/{user}'
 */
export const show = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/accounts/{user}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::show
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:212
 * @route '/admin/accounts/{user}'
 */
show.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return show.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::show
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:212
 * @route '/admin/accounts/{user}'
 */
show.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::show
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:212
 * @route '/admin/accounts/{user}'
 */
show.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::show
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:212
 * @route '/admin/accounts/{user}'
 */
    const showForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::show
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:212
 * @route '/admin/accounts/{user}'
 */
        showForm.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::show
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:212
 * @route '/admin/accounts/{user}'
 */
        showForm.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::toggleAdmin
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:89
 * @route '/admin/accounts/{user}/toggle-admin'
 */
export const toggleAdmin = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleAdmin.url(args, options),
    method: 'post',
})

toggleAdmin.definition = {
    methods: ["post"],
    url: '/admin/accounts/{user}/toggle-admin',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::toggleAdmin
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:89
 * @route '/admin/accounts/{user}/toggle-admin'
 */
toggleAdmin.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return toggleAdmin.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::toggleAdmin
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:89
 * @route '/admin/accounts/{user}/toggle-admin'
 */
toggleAdmin.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleAdmin.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::toggleAdmin
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:89
 * @route '/admin/accounts/{user}/toggle-admin'
 */
    const toggleAdminForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleAdmin.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::toggleAdmin
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:89
 * @route '/admin/accounts/{user}/toggle-admin'
 */
        toggleAdminForm.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleAdmin.url(args, options),
            method: 'post',
        })
    
    toggleAdmin.form = toggleAdminForm
/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::toggleVerification
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:115
 * @route '/admin/accounts/{user}/toggle-verification'
 */
export const toggleVerification = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleVerification.url(args, options),
    method: 'post',
})

toggleVerification.definition = {
    methods: ["post"],
    url: '/admin/accounts/{user}/toggle-verification',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::toggleVerification
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:115
 * @route '/admin/accounts/{user}/toggle-verification'
 */
toggleVerification.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return toggleVerification.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::toggleVerification
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:115
 * @route '/admin/accounts/{user}/toggle-verification'
 */
toggleVerification.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleVerification.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::toggleVerification
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:115
 * @route '/admin/accounts/{user}/toggle-verification'
 */
    const toggleVerificationForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleVerification.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::toggleVerification
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:115
 * @route '/admin/accounts/{user}/toggle-verification'
 */
        toggleVerificationForm.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleVerification.url(args, options),
            method: 'post',
        })
    
    toggleVerification.form = toggleVerificationForm
/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::clearOtp
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:240
 * @route '/admin/accounts/{user}/clear-otp'
 */
export const clearOtp = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clearOtp.url(args, options),
    method: 'post',
})

clearOtp.definition = {
    methods: ["post"],
    url: '/admin/accounts/{user}/clear-otp',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::clearOtp
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:240
 * @route '/admin/accounts/{user}/clear-otp'
 */
clearOtp.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return clearOtp.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::clearOtp
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:240
 * @route '/admin/accounts/{user}/clear-otp'
 */
clearOtp.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clearOtp.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::clearOtp
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:240
 * @route '/admin/accounts/{user}/clear-otp'
 */
    const clearOtpForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clearOtp.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::clearOtp
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:240
 * @route '/admin/accounts/{user}/clear-otp'
 */
        clearOtpForm.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clearOtp.url(args, options),
            method: 'post',
        })
    
    clearOtp.form = clearOtpForm
/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::clear2fa
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:251
 * @route '/admin/accounts/{user}/clear-2fa'
 */
export const clear2fa = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clear2fa.url(args, options),
    method: 'post',
})

clear2fa.definition = {
    methods: ["post"],
    url: '/admin/accounts/{user}/clear-2fa',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::clear2fa
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:251
 * @route '/admin/accounts/{user}/clear-2fa'
 */
clear2fa.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return clear2fa.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::clear2fa
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:251
 * @route '/admin/accounts/{user}/clear-2fa'
 */
clear2fa.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: clear2fa.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::clear2fa
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:251
 * @route '/admin/accounts/{user}/clear-2fa'
 */
    const clear2faForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: clear2fa.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::clear2fa
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:251
 * @route '/admin/accounts/{user}/clear-2fa'
 */
        clear2faForm.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: clear2fa.url(args, options),
            method: 'post',
        })
    
    clear2fa.form = clear2faForm
/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::destroy
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:147
 * @route '/admin/accounts/{user}'
 */
export const destroy = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/accounts/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::destroy
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:147
 * @route '/admin/accounts/{user}'
 */
destroy.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return destroy.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::destroy
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:147
 * @route '/admin/accounts/{user}'
 */
destroy.delete = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::destroy
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:147
 * @route '/admin/accounts/{user}'
 */
    const destroyForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::destroy
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:147
 * @route '/admin/accounts/{user}'
 */
        destroyForm.delete = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const accounts = {
    show: Object.assign(show, show),
toggleAdmin: Object.assign(toggleAdmin, toggleAdmin),
toggleVerification: Object.assign(toggleVerification, toggleVerification),
clearOtp: Object.assign(clearOtp, clearOtp),
clear2fa: Object.assign(clear2fa, clear2fa),
destroy: Object.assign(destroy, destroy),
}

export default accounts