import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import cotd5ac7c7 from './cotd'
import accountsDb024e from './accounts'
import contacts677fa8 from './contacts'
/**
* @see \App\Http\Controllers\Admin\CotdController::cotd
 * @see app/Http/Controllers/Admin/CotdController.php:16
 * @route '/admin/cotd'
 */
export const cotd = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cotd.url(options),
    method: 'get',
})

cotd.definition = {
    methods: ["get","head"],
    url: '/admin/cotd',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\CotdController::cotd
 * @see app/Http/Controllers/Admin/CotdController.php:16
 * @route '/admin/cotd'
 */
cotd.url = (options?: RouteQueryOptions) => {
    return cotd.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\CotdController::cotd
 * @see app/Http/Controllers/Admin/CotdController.php:16
 * @route '/admin/cotd'
 */
cotd.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cotd.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\CotdController::cotd
 * @see app/Http/Controllers/Admin/CotdController.php:16
 * @route '/admin/cotd'
 */
cotd.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cotd.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\CotdController::cotd
 * @see app/Http/Controllers/Admin/CotdController.php:16
 * @route '/admin/cotd'
 */
    const cotdForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: cotd.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\CotdController::cotd
 * @see app/Http/Controllers/Admin/CotdController.php:16
 * @route '/admin/cotd'
 */
        cotdForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cotd.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\CotdController::cotd
 * @see app/Http/Controllers/Admin/CotdController.php:16
 * @route '/admin/cotd'
 */
        cotdForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cotd.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    cotd.form = cotdForm
/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::accounts
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:18
 * @route '/admin/accounts'
 */
export const accounts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: accounts.url(options),
    method: 'get',
})

accounts.definition = {
    methods: ["get","head"],
    url: '/admin/accounts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::accounts
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:18
 * @route '/admin/accounts'
 */
accounts.url = (options?: RouteQueryOptions) => {
    return accounts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::accounts
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:18
 * @route '/admin/accounts'
 */
accounts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: accounts.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AccountHandlerController::accounts
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:18
 * @route '/admin/accounts'
 */
accounts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: accounts.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::accounts
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:18
 * @route '/admin/accounts'
 */
    const accountsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: accounts.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::accounts
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:18
 * @route '/admin/accounts'
 */
        accountsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: accounts.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AccountHandlerController::accounts
 * @see app/Http/Controllers/Admin/AccountHandlerController.php:18
 * @route '/admin/accounts'
 */
        accountsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: accounts.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    accounts.form = accountsForm
/**
* @see \App\Http\Controllers\ContactController::contacts
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
export const contacts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contacts.url(options),
    method: 'get',
})

contacts.definition = {
    methods: ["get","head"],
    url: '/admin/contacts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContactController::contacts
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
contacts.url = (options?: RouteQueryOptions) => {
    return contacts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContactController::contacts
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
contacts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contacts.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ContactController::contacts
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
contacts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: contacts.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ContactController::contacts
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
    const contactsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: contacts.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ContactController::contacts
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
        contactsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contacts.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ContactController::contacts
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
        contactsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contacts.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    contacts.form = contactsForm
const admin = {
    cotd: Object.assign(cotd, cotd5ac7c7),
accounts: Object.assign(accounts, accountsDb024e),
contacts: Object.assign(contacts, contacts677fa8),
}

export default admin