import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ContactController::deleteMethod
 * @see app/Http/Controllers/ContactController.php:46
 * @route '/admin/contacts/delete'
 */
export const deleteMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deleteMethod.url(options),
    method: 'post',
})

deleteMethod.definition = {
    methods: ["post"],
    url: '/admin/contacts/delete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ContactController::deleteMethod
 * @see app/Http/Controllers/ContactController.php:46
 * @route '/admin/contacts/delete'
 */
deleteMethod.url = (options?: RouteQueryOptions) => {
    return deleteMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContactController::deleteMethod
 * @see app/Http/Controllers/ContactController.php:46
 * @route '/admin/contacts/delete'
 */
deleteMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deleteMethod.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ContactController::deleteMethod
 * @see app/Http/Controllers/ContactController.php:46
 * @route '/admin/contacts/delete'
 */
    const deleteMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteMethod.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ContactController::deleteMethod
 * @see app/Http/Controllers/ContactController.php:46
 * @route '/admin/contacts/delete'
 */
        deleteMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteMethod.url(options),
            method: 'post',
        })
    
    deleteMethod.form = deleteMethodForm
const contacts = {
    delete: Object.assign(deleteMethod, deleteMethod),
}

export default contacts