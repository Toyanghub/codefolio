import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\NewsletterController::subscribe
 * @see app/Http/Controllers/NewsletterController.php:16
 * @route '/newsletter/subscribe'
 */
export const subscribe = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: subscribe.url(options),
    method: 'post',
})

subscribe.definition = {
    methods: ["post"],
    url: '/newsletter/subscribe',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NewsletterController::subscribe
 * @see app/Http/Controllers/NewsletterController.php:16
 * @route '/newsletter/subscribe'
 */
subscribe.url = (options?: RouteQueryOptions) => {
    return subscribe.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NewsletterController::subscribe
 * @see app/Http/Controllers/NewsletterController.php:16
 * @route '/newsletter/subscribe'
 */
subscribe.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: subscribe.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NewsletterController::subscribe
 * @see app/Http/Controllers/NewsletterController.php:16
 * @route '/newsletter/subscribe'
 */
    const subscribeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: subscribe.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NewsletterController::subscribe
 * @see app/Http/Controllers/NewsletterController.php:16
 * @route '/newsletter/subscribe'
 */
        subscribeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: subscribe.url(options),
            method: 'post',
        })
    
    subscribe.form = subscribeForm
/**
* @see \App\Http\Controllers\NewsletterController::unsubscribe
 * @see app/Http/Controllers/NewsletterController.php:64
 * @route '/newsletter/unsubscribe'
 */
export const unsubscribe = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unsubscribe.url(options),
    method: 'post',
})

unsubscribe.definition = {
    methods: ["post"],
    url: '/newsletter/unsubscribe',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NewsletterController::unsubscribe
 * @see app/Http/Controllers/NewsletterController.php:64
 * @route '/newsletter/unsubscribe'
 */
unsubscribe.url = (options?: RouteQueryOptions) => {
    return unsubscribe.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NewsletterController::unsubscribe
 * @see app/Http/Controllers/NewsletterController.php:64
 * @route '/newsletter/unsubscribe'
 */
unsubscribe.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unsubscribe.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NewsletterController::unsubscribe
 * @see app/Http/Controllers/NewsletterController.php:64
 * @route '/newsletter/unsubscribe'
 */
    const unsubscribeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unsubscribe.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NewsletterController::unsubscribe
 * @see app/Http/Controllers/NewsletterController.php:64
 * @route '/newsletter/unsubscribe'
 */
        unsubscribeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unsubscribe.url(options),
            method: 'post',
        })
    
    unsubscribe.form = unsubscribeForm
const newsletter = {
    subscribe: Object.assign(subscribe, subscribe),
unsubscribe: Object.assign(unsubscribe, unsubscribe),
}

export default newsletter