import of from './of'
const terms = {
    of: Object.assign(of, of),
}

export default terms