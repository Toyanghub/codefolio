import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
 * @see routes/web.php:35
 * @route '/terms-of-service'
 */
export const service = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: service.url(options),
    method: 'get',
})

service.definition = {
    methods: ["get","head"],
    url: '/terms-of-service',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:35
 * @route '/terms-of-service'
 */
service.url = (options?: RouteQueryOptions) => {
    return service.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:35
 * @route '/terms-of-service'
 */
service.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: service.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:35
 * @route '/terms-of-service'
 */
service.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: service.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:35
 * @route '/terms-of-service'
 */
    const serviceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: service.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:35
 * @route '/terms-of-service'
 */
        serviceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: service.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:35
 * @route '/terms-of-service'
 */
        serviceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: service.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    service.form = serviceForm
const of = {
    service: Object.assign(service, service),
}

export default of