import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\EmailVerificationController::verify
 * @see app/Http/Controllers/EmailVerificationController.php:48
 * @route '/verify-otp'
 */
export const verify = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(options),
    method: 'post',
})

verify.definition = {
    methods: ["post"],
    url: '/verify-otp',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\EmailVerificationController::verify
 * @see app/Http/Controllers/EmailVerificationController.php:48
 * @route '/verify-otp'
 */
verify.url = (options?: RouteQueryOptions) => {
    return verify.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmailVerificationController::verify
 * @see app/Http/Controllers/EmailVerificationController.php:48
 * @route '/verify-otp'
 */
verify.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\EmailVerificationController::verify
 * @see app/Http/Controllers/EmailVerificationController.php:48
 * @route '/verify-otp'
 */
    const verifyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: verify.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\EmailVerificationController::verify
 * @see app/Http/Controllers/EmailVerificationController.php:48
 * @route '/verify-otp'
 */
        verifyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: verify.url(options),
            method: 'post',
        })
    
    verify.form = verifyForm
/**
* @see \App\Http\Controllers\EmailVerificationController::resend
 * @see app/Http/Controllers/EmailVerificationController.php:79
 * @route '/verify-otp/resend'
 */
export const resend = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resend.url(options),
    method: 'post',
})

resend.definition = {
    methods: ["post"],
    url: '/verify-otp/resend',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\EmailVerificationController::resend
 * @see app/Http/Controllers/EmailVerificationController.php:79
 * @route '/verify-otp/resend'
 */
resend.url = (options?: RouteQueryOptions) => {
    return resend.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmailVerificationController::resend
 * @see app/Http/Controllers/EmailVerificationController.php:79
 * @route '/verify-otp/resend'
 */
resend.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resend.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\EmailVerificationController::resend
 * @see app/Http/Controllers/EmailVerificationController.php:79
 * @route '/verify-otp/resend'
 */
    const resendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resend.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\EmailVerificationController::resend
 * @see app/Http/Controllers/EmailVerificationController.php:79
 * @route '/verify-otp/resend'
 */
        resendForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resend.url(options),
            method: 'post',
        })
    
    resend.form = resendForm
const verifyOtp = {
    verify: Object.assign(verify, verify),
resend: Object.assign(resend, resend),
}

export default verifyOtp