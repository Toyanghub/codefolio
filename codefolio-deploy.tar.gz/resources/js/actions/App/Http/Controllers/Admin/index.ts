import CotdController from './CotdController'
import AccountHandlerController from './AccountHandlerController'
const Admin = {
    CotdController: Object.assign(CotdController, CotdController),
AccountHandlerController: Object.assign(AccountHandlerController, AccountHandlerController),
}

export default Admin