import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ContactController::store
 * @see app/Http/Controllers/ContactController.php:11
 * @route '/contact'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/contact',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ContactController::store
 * @see app/Http/Controllers/ContactController.php:11
 * @route '/contact'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContactController::store
 * @see app/Http/Controllers/ContactController.php:11
 * @route '/contact'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ContactController::store
 * @see app/Http/Controllers/ContactController.php:11
 * @route '/contact'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ContactController::store
 * @see app/Http/Controllers/ContactController.php:11
 * @route '/contact'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ContactController::index
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/contacts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ContactController::index
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContactController::index
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ContactController::index
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ContactController::index
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ContactController::index
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ContactController::index
 * @see app/Http/Controllers/ContactController.php:24
 * @route '/admin/contacts'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ContactController::deleteMultiple
 * @see app/Http/Controllers/ContactController.php:46
 * @route '/admin/contacts/delete'
 */
export const deleteMultiple = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deleteMultiple.url(options),
    method: 'post',
})

deleteMultiple.definition = {
    methods: ["post"],
    url: '/admin/contacts/delete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ContactController::deleteMultiple
 * @see app/Http/Controllers/ContactController.php:46
 * @route '/admin/contacts/delete'
 */
deleteMultiple.url = (options?: RouteQueryOptions) => {
    return deleteMultiple.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ContactController::deleteMultiple
 * @see app/Http/Controllers/ContactController.php:46
 * @route '/admin/contacts/delete'
 */
deleteMultiple.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: deleteMultiple.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ContactController::deleteMultiple
 * @see app/Http/Controllers/ContactController.php:46
 * @route '/admin/contacts/delete'
 */
    const deleteMultipleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteMultiple.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ContactController::deleteMultiple
 * @see app/Http/Controllers/ContactController.php:46
 * @route '/admin/contacts/delete'
 */
        deleteMultipleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteMultiple.url(options),
            method: 'post',
        })
    
    deleteMultiple.form = deleteMultipleForm
const ContactController = { store, index, deleteMultiple }

export default ContactController