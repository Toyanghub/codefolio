import ObservatoryController from './ObservatoryController'
import WorksController from './WorksController'
import PortfolioDetailController from './PortfolioDetailController'
import ContactController from './ContactController'
import Auth from './Auth'
import NewsletterController from './NewsletterController'
import SitemapController from './SitemapController'
import EmailVerificationController from './EmailVerificationController'
import Admin from './Admin'
import Settings from './Settings'
const Controllers = {
    ObservatoryController: Object.assign(ObservatoryController, ObservatoryController),
WorksController: Object.assign(WorksController, WorksController),
PortfolioDetailController: Object.assign(PortfolioDetailController, PortfolioDetailController),
ContactController: Object.assign(ContactController, ContactController),
Auth: Object.assign(Auth, Auth),
NewsletterController: Object.assign(NewsletterController, NewsletterController),
SitemapController: Object.assign(SitemapController, SitemapController),
EmailVerificationController: Object.assign(EmailVerificationController, EmailVerificationController),
Admin: Object.assign(Admin, Admin),
Settings: Object.assign(Settings, Settings),
}

export default Controllers