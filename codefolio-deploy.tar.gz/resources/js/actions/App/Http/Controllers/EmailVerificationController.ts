import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\EmailVerificationController::show
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/verify-otp',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\EmailVerificationController::show
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmailVerificationController::show
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\EmailVerificationController::show
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\EmailVerificationController::show
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\EmailVerificationController::show
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\EmailVerificationController::show
 * @see app/Http/Controllers/EmailVerificationController.php:20
 * @route '/verify-otp'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\EmailVerificationController::verifyOtp
 * @see app/Http/Controllers/EmailVerificationController.php:48
 * @route '/verify-otp'
 */
export const verifyOtp = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyOtp.url(options),
    method: 'post',
})

verifyOtp.definition = {
    methods: ["post"],
    url: '/verify-otp',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\EmailVerificationController::verifyOtp
 * @see app/Http/Controllers/EmailVerificationController.php:48
 * @route '/verify-otp'
 */
verifyOtp.url = (options?: RouteQueryOptions) => {
    return verifyOtp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmailVerificationController::verifyOtp
 * @see app/Http/Controllers/EmailVerificationController.php:48
 * @route '/verify-otp'
 */
verifyOtp.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyOtp.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\EmailVerificationController::verifyOtp
 * @see app/Http/Controllers/EmailVerificationController.php:48
 * @route '/verify-otp'
 */
    const verifyOtpForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: verifyOtp.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\EmailVerificationController::verifyOtp
 * @see app/Http/Controllers/EmailVerificationController.php:48
 * @route '/verify-otp'
 */
        verifyOtpForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: verifyOtp.url(options),
            method: 'post',
        })
    
    verifyOtp.form = verifyOtpForm
/**
* @see \App\Http\Controllers\EmailVerificationController::resendOtp
 * @see app/Http/Controllers/EmailVerificationController.php:79
 * @route '/verify-otp/resend'
 */
export const resendOtp = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resendOtp.url(options),
    method: 'post',
})

resendOtp.definition = {
    methods: ["post"],
    url: '/verify-otp/resend',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\EmailVerificationController::resendOtp
 * @see app/Http/Controllers/EmailVerificationController.php:79
 * @route '/verify-otp/resend'
 */
resendOtp.url = (options?: RouteQueryOptions) => {
    return resendOtp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmailVerificationController::resendOtp
 * @see app/Http/Controllers/EmailVerificationController.php:79
 * @route '/verify-otp/resend'
 */
resendOtp.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resendOtp.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\EmailVerificationController::resendOtp
 * @see app/Http/Controllers/EmailVerificationController.php:79
 * @route '/verify-otp/resend'
 */
    const resendOtpForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resendOtp.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\EmailVerificationController::resendOtp
 * @see app/Http/Controllers/EmailVerificationController.php:79
 * @route '/verify-otp/resend'
 */
        resendOtpForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resendOtp.url(options),
            method: 'post',
        })
    
    resendOtp.form = resendOtpForm
const EmailVerificationController = { show, verifyOtp, resendOtp }

export default EmailVerificationController