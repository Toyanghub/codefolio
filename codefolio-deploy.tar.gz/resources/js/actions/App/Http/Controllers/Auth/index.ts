import GoogleAuthController from './GoogleAuthController'
import GitHubAuthController from './GitHubAuthController'
const Auth = {
    GoogleAuthController: Object.assign(GoogleAuthController, GoogleAuthController),
GitHubAuthController: Object.assign(GitHubAuthController, GitHubAuthController),
}

export default Auth