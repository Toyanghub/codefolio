import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\GitHubAuthController::redirectToGitHub
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:23
 * @route '/auth/github'
 */
export const redirectToGitHub = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToGitHub.url(options),
    method: 'get',
})

redirectToGitHub.definition = {
    methods: ["get","head"],
    url: '/auth/github',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\GitHubAuthController::redirectToGitHub
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:23
 * @route '/auth/github'
 */
redirectToGitHub.url = (options?: RouteQueryOptions) => {
    return redirectToGitHub.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\GitHubAuthController::redirectToGitHub
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:23
 * @route '/auth/github'
 */
redirectToGitHub.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirectToGitHub.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\GitHubAuthController::redirectToGitHub
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:23
 * @route '/auth/github'
 */
redirectToGitHub.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirectToGitHub.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\GitHubAuthController::redirectToGitHub
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:23
 * @route '/auth/github'
 */
    const redirectToGitHubForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: redirectToGitHub.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\GitHubAuthController::redirectToGitHub
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:23
 * @route '/auth/github'
 */
        redirectToGitHubForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirectToGitHub.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\GitHubAuthController::redirectToGitHub
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:23
 * @route '/auth/github'
 */
        redirectToGitHubForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirectToGitHub.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    redirectToGitHub.form = redirectToGitHubForm
/**
* @see \App\Http\Controllers\Auth\GitHubAuthController::handleGitHubCallback
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:31
 * @route '/auth/github/callback'
 */
export const handleGitHubCallback = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: handleGitHubCallback.url(options),
    method: 'get',
})

handleGitHubCallback.definition = {
    methods: ["get","head"],
    url: '/auth/github/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\GitHubAuthController::handleGitHubCallback
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:31
 * @route '/auth/github/callback'
 */
handleGitHubCallback.url = (options?: RouteQueryOptions) => {
    return handleGitHubCallback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\GitHubAuthController::handleGitHubCallback
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:31
 * @route '/auth/github/callback'
 */
handleGitHubCallback.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: handleGitHubCallback.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\GitHubAuthController::handleGitHubCallback
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:31
 * @route '/auth/github/callback'
 */
handleGitHubCallback.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: handleGitHubCallback.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\GitHubAuthController::handleGitHubCallback
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:31
 * @route '/auth/github/callback'
 */
    const handleGitHubCallbackForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: handleGitHubCallback.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\GitHubAuthController::handleGitHubCallback
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:31
 * @route '/auth/github/callback'
 */
        handleGitHubCallbackForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: handleGitHubCallback.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\GitHubAuthController::handleGitHubCallback
 * @see app/Http/Controllers/Auth/GitHubAuthController.php:31
 * @route '/auth/github/callback'
 */
        handleGitHubCallbackForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: handleGitHubCallback.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    handleGitHubCallback.form = handleGitHubCallbackForm
const GitHubAuthController = { redirectToGitHub, handleGitHubCallback }

export default GitHubAuthController