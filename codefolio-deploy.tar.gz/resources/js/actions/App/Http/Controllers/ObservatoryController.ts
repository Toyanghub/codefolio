import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ObservatoryController::index
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/observatory',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ObservatoryController::index
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ObservatoryController::index
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ObservatoryController::index
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ObservatoryController::index
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ObservatoryController::index
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ObservatoryController::index
 * @see app/Http/Controllers/ObservatoryController.php:18
 * @route '/observatory'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const ObservatoryController = { index }

export default ObservatoryController