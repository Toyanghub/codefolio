import ProfileController from './ProfileController'
import PortfolioController from './PortfolioController'
import PasswordController from './PasswordController'
import TwoFactorAuthenticationController from './TwoFactorAuthenticationController'
const Settings = {
    ProfileController: Object.assign(ProfileController, ProfileController),
PortfolioController: Object.assign(PortfolioController, PortfolioController),
PasswordController: Object.assign(PasswordController, PasswordController),
TwoFactorAuthenticationController: Object.assign(TwoFactorAuthenticationController, TwoFactorAuthenticationController),
}

export default Settings