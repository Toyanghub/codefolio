import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/portfolio',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\PortfolioController::edit
 * @see app/Http/Controllers/Settings/PortfolioController.php:20
 * @route '/settings/portfolio'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::completeSetup
 * @see app/Http/Controllers/Settings/PortfolioController.php:231
 * @route '/settings/portfolio/complete'
 */
export const completeSetup = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: completeSetup.url(options),
    method: 'post',
})

completeSetup.definition = {
    methods: ["post"],
    url: '/settings/portfolio/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::completeSetup
 * @see app/Http/Controllers/Settings/PortfolioController.php:231
 * @route '/settings/portfolio/complete'
 */
completeSetup.url = (options?: RouteQueryOptions) => {
    return completeSetup.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::completeSetup
 * @see app/Http/Controllers/Settings/PortfolioController.php:231
 * @route '/settings/portfolio/complete'
 */
completeSetup.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: completeSetup.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::completeSetup
 * @see app/Http/Controllers/Settings/PortfolioController.php:231
 * @route '/settings/portfolio/complete'
 */
    const completeSetupForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: completeSetup.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::completeSetup
 * @see app/Http/Controllers/Settings/PortfolioController.php:231
 * @route '/settings/portfolio/complete'
 */
        completeSetupForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: completeSetup.url(options),
            method: 'post',
        })
    
    completeSetup.form = completeSetupForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::generateScreenshots
 * @see app/Http/Controllers/Settings/PortfolioController.php:263
 * @route '/settings/portfolio/generate-screenshots'
 */
export const generateScreenshots = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateScreenshots.url(options),
    method: 'post',
})

generateScreenshots.definition = {
    methods: ["post"],
    url: '/settings/portfolio/generate-screenshots',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::generateScreenshots
 * @see app/Http/Controllers/Settings/PortfolioController.php:263
 * @route '/settings/portfolio/generate-screenshots'
 */
generateScreenshots.url = (options?: RouteQueryOptions) => {
    return generateScreenshots.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::generateScreenshots
 * @see app/Http/Controllers/Settings/PortfolioController.php:263
 * @route '/settings/portfolio/generate-screenshots'
 */
generateScreenshots.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateScreenshots.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::generateScreenshots
 * @see app/Http/Controllers/Settings/PortfolioController.php:263
 * @route '/settings/portfolio/generate-screenshots'
 */
    const generateScreenshotsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generateScreenshots.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::generateScreenshots
 * @see app/Http/Controllers/Settings/PortfolioController.php:263
 * @route '/settings/portfolio/generate-screenshots'
 */
        generateScreenshotsForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generateScreenshots.url(options),
            method: 'post',
        })
    
    generateScreenshots.form = generateScreenshotsForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateDesktopImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:149
 * @route '/settings/portfolio/desktop-image'
 */
export const updateDesktopImage = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateDesktopImage.url(options),
    method: 'post',
})

updateDesktopImage.definition = {
    methods: ["post"],
    url: '/settings/portfolio/desktop-image',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateDesktopImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:149
 * @route '/settings/portfolio/desktop-image'
 */
updateDesktopImage.url = (options?: RouteQueryOptions) => {
    return updateDesktopImage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateDesktopImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:149
 * @route '/settings/portfolio/desktop-image'
 */
updateDesktopImage.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateDesktopImage.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateDesktopImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:149
 * @route '/settings/portfolio/desktop-image'
 */
    const updateDesktopImageForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateDesktopImage.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateDesktopImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:149
 * @route '/settings/portfolio/desktop-image'
 */
        updateDesktopImageForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateDesktopImage.url(options),
            method: 'post',
        })
    
    updateDesktopImage.form = updateDesktopImageForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateMobileImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:175
 * @route '/settings/portfolio/mobile-image'
 */
export const updateMobileImage = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateMobileImage.url(options),
    method: 'post',
})

updateMobileImage.definition = {
    methods: ["post"],
    url: '/settings/portfolio/mobile-image',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateMobileImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:175
 * @route '/settings/portfolio/mobile-image'
 */
updateMobileImage.url = (options?: RouteQueryOptions) => {
    return updateMobileImage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateMobileImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:175
 * @route '/settings/portfolio/mobile-image'
 */
updateMobileImage.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateMobileImage.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateMobileImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:175
 * @route '/settings/portfolio/mobile-image'
 */
    const updateMobileImageForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateMobileImage.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateMobileImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:175
 * @route '/settings/portfolio/mobile-image'
 */
        updateMobileImageForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateMobileImage.url(options),
            method: 'post',
        })
    
    updateMobileImage.form = updateMobileImageForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteDesktopImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:201
 * @route '/settings/portfolio/desktop-image'
 */
export const deleteDesktopImage = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteDesktopImage.url(options),
    method: 'delete',
})

deleteDesktopImage.definition = {
    methods: ["delete"],
    url: '/settings/portfolio/desktop-image',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteDesktopImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:201
 * @route '/settings/portfolio/desktop-image'
 */
deleteDesktopImage.url = (options?: RouteQueryOptions) => {
    return deleteDesktopImage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteDesktopImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:201
 * @route '/settings/portfolio/desktop-image'
 */
deleteDesktopImage.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteDesktopImage.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteDesktopImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:201
 * @route '/settings/portfolio/desktop-image'
 */
    const deleteDesktopImageForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteDesktopImage.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteDesktopImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:201
 * @route '/settings/portfolio/desktop-image'
 */
        deleteDesktopImageForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteDesktopImage.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteDesktopImage.form = deleteDesktopImageForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteMobileImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:216
 * @route '/settings/portfolio/mobile-image'
 */
export const deleteMobileImage = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMobileImage.url(options),
    method: 'delete',
})

deleteMobileImage.definition = {
    methods: ["delete"],
    url: '/settings/portfolio/mobile-image',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteMobileImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:216
 * @route '/settings/portfolio/mobile-image'
 */
deleteMobileImage.url = (options?: RouteQueryOptions) => {
    return deleteMobileImage.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteMobileImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:216
 * @route '/settings/portfolio/mobile-image'
 */
deleteMobileImage.delete = (options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteMobileImage.url(options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteMobileImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:216
 * @route '/settings/portfolio/mobile-image'
 */
    const deleteMobileImageForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteMobileImage.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::deleteMobileImage
 * @see app/Http/Controllers/Settings/PortfolioController.php:216
 * @route '/settings/portfolio/mobile-image'
 */
        deleteMobileImageForm.delete = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteMobileImage.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteMobileImage.form = deleteMobileImageForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateWebsiteUrl
 * @see app/Http/Controllers/Settings/PortfolioController.php:54
 * @route '/settings/portfolio/website-url'
 */
export const updateWebsiteUrl = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateWebsiteUrl.url(options),
    method: 'patch',
})

updateWebsiteUrl.definition = {
    methods: ["patch"],
    url: '/settings/portfolio/website-url',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateWebsiteUrl
 * @see app/Http/Controllers/Settings/PortfolioController.php:54
 * @route '/settings/portfolio/website-url'
 */
updateWebsiteUrl.url = (options?: RouteQueryOptions) => {
    return updateWebsiteUrl.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateWebsiteUrl
 * @see app/Http/Controllers/Settings/PortfolioController.php:54
 * @route '/settings/portfolio/website-url'
 */
updateWebsiteUrl.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateWebsiteUrl.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateWebsiteUrl
 * @see app/Http/Controllers/Settings/PortfolioController.php:54
 * @route '/settings/portfolio/website-url'
 */
    const updateWebsiteUrlForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateWebsiteUrl.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateWebsiteUrl
 * @see app/Http/Controllers/Settings/PortfolioController.php:54
 * @route '/settings/portfolio/website-url'
 */
        updateWebsiteUrlForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateWebsiteUrl.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateWebsiteUrl.form = updateWebsiteUrlForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateDescription
 * @see app/Http/Controllers/Settings/PortfolioController.php:70
 * @route '/settings/portfolio/description'
 */
export const updateDescription = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDescription.url(options),
    method: 'patch',
})

updateDescription.definition = {
    methods: ["patch"],
    url: '/settings/portfolio/description',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateDescription
 * @see app/Http/Controllers/Settings/PortfolioController.php:70
 * @route '/settings/portfolio/description'
 */
updateDescription.url = (options?: RouteQueryOptions) => {
    return updateDescription.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateDescription
 * @see app/Http/Controllers/Settings/PortfolioController.php:70
 * @route '/settings/portfolio/description'
 */
updateDescription.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateDescription.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateDescription
 * @see app/Http/Controllers/Settings/PortfolioController.php:70
 * @route '/settings/portfolio/description'
 */
    const updateDescriptionForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateDescription.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateDescription
 * @see app/Http/Controllers/Settings/PortfolioController.php:70
 * @route '/settings/portfolio/description'
 */
        updateDescriptionForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateDescription.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateDescription.form = updateDescriptionForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateSkills
 * @see app/Http/Controllers/Settings/PortfolioController.php:86
 * @route '/settings/portfolio/skills'
 */
export const updateSkills = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateSkills.url(options),
    method: 'patch',
})

updateSkills.definition = {
    methods: ["patch"],
    url: '/settings/portfolio/skills',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateSkills
 * @see app/Http/Controllers/Settings/PortfolioController.php:86
 * @route '/settings/portfolio/skills'
 */
updateSkills.url = (options?: RouteQueryOptions) => {
    return updateSkills.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateSkills
 * @see app/Http/Controllers/Settings/PortfolioController.php:86
 * @route '/settings/portfolio/skills'
 */
updateSkills.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateSkills.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateSkills
 * @see app/Http/Controllers/Settings/PortfolioController.php:86
 * @route '/settings/portfolio/skills'
 */
    const updateSkillsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateSkills.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateSkills
 * @see app/Http/Controllers/Settings/PortfolioController.php:86
 * @route '/settings/portfolio/skills'
 */
        updateSkillsForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateSkills.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateSkills.form = updateSkillsForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateTechStacks
 * @see app/Http/Controllers/Settings/PortfolioController.php:101
 * @route '/settings/portfolio/tech-stacks'
 */
export const updateTechStacks = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateTechStacks.url(options),
    method: 'patch',
})

updateTechStacks.definition = {
    methods: ["patch"],
    url: '/settings/portfolio/tech-stacks',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateTechStacks
 * @see app/Http/Controllers/Settings/PortfolioController.php:101
 * @route '/settings/portfolio/tech-stacks'
 */
updateTechStacks.url = (options?: RouteQueryOptions) => {
    return updateTechStacks.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateTechStacks
 * @see app/Http/Controllers/Settings/PortfolioController.php:101
 * @route '/settings/portfolio/tech-stacks'
 */
updateTechStacks.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateTechStacks.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateTechStacks
 * @see app/Http/Controllers/Settings/PortfolioController.php:101
 * @route '/settings/portfolio/tech-stacks'
 */
    const updateTechStacksForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateTechStacks.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateTechStacks
 * @see app/Http/Controllers/Settings/PortfolioController.php:101
 * @route '/settings/portfolio/tech-stacks'
 */
        updateTechStacksForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateTechStacks.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateTechStacks.form = updateTechStacksForm
/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateProfessions
 * @see app/Http/Controllers/Settings/PortfolioController.php:116
 * @route '/settings/portfolio/professions'
 */
export const updateProfessions = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateProfessions.url(options),
    method: 'patch',
})

updateProfessions.definition = {
    methods: ["patch"],
    url: '/settings/portfolio/professions',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateProfessions
 * @see app/Http/Controllers/Settings/PortfolioController.php:116
 * @route '/settings/portfolio/professions'
 */
updateProfessions.url = (options?: RouteQueryOptions) => {
    return updateProfessions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\PortfolioController::updateProfessions
 * @see app/Http/Controllers/Settings/PortfolioController.php:116
 * @route '/settings/portfolio/professions'
 */
updateProfessions.patch = (options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateProfessions.url(options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateProfessions
 * @see app/Http/Controllers/Settings/PortfolioController.php:116
 * @route '/settings/portfolio/professions'
 */
    const updateProfessionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateProfessions.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\PortfolioController::updateProfessions
 * @see app/Http/Controllers/Settings/PortfolioController.php:116
 * @route '/settings/portfolio/professions'
 */
        updateProfessionsForm.patch = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateProfessions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateProfessions.form = updateProfessionsForm
const PortfolioController = { edit, completeSetup, generateScreenshots, updateDesktopImage, updateMobileImage, deleteDesktopImage, deleteMobileImage, updateWebsiteUrl, updateDescription, updateSkills, updateTechStacks, updateProfessions }

export default PortfolioController