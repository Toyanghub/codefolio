<tr>
<td>
<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td class="content-cell" align="center">
<?php echo new \Illuminate\Support\EncodedHtmlString(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
</td>
</tr>
<?php /**PATH D:\MEH FILES\WEB CODE DEV\ANTIGRAVITY-GOOGLE-PROJECT\code-folio\my-app\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>