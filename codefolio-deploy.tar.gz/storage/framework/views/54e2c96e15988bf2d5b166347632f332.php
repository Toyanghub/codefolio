<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\MEH FILES\WEB CODE DEV\ANTIGRAVITY-GOOGLE-PROJECT\code-folio\my-app\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>