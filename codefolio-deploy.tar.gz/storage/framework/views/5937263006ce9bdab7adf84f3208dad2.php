<?php echo e($slot); ?>

<?php /**PATH D:\MEH FILES\WEB CODE DEV\ANTIGRAVITY-GOOGLE-PROJECT\code-folio\my-app\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>